<!DOCTYPE html>
<html>
<head>
	<title>page avc php</title>
	<meta charset="utf-8/">
</head>
<body>
<p>ceci est un code variable</p>
<?php
 
 
?>
</body>
</html> 